rm -f acf351b_python_submission.zip
zip -r acf351b_python_submission.zip *.docx *.ipynb first_part/*py second_part/*py

